package com.enigma.wms_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WmsApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
