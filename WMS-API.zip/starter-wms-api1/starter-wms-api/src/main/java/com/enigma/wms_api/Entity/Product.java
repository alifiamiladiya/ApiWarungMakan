package com.enigma.wms_api.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.math.BigDecimal;
import java.util.Arrays;

@Entity
@Table(name = "m-product")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Product {
    public Arrays getProductPrices;
    @Id
    @GenericGenerator(strategy = "uuid2",name = "system-uuid")
    @GeneratedValue(generator = "system-uuid")
    private String productId;
    @Column(name = "productPriceId" , nullable = false , unique = true)
    private String productPriceId;
    @Column(name = "productCode" , nullable = false)
    private String productCode;
    @Column(name = "productName" , nullable = false)
    private String productName;
    @Column(name = "price" , nullable = false , unique = true)
    private BigDecimal price;


    public static Product builder() {
        return new Product() ;
    }

    public ResponseStatus ProductName(@NotBlank(message = "product name is required") String productName) {
        return null;
    }
}
