package com.enigma.wms_api.Controller;

import com.enigma.wms_api.Entity.Branch;
import com.enigma.wms_api.Service.BranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/store")
public class BranchController {
    private final BranchService branchService;
    @PostMapping
    public Branch createNewbranch(@   RequestBody Branch branch){
        return branchService.create(branch);
    }

    @GetMapping(value = "/{id}")
    public Branch getBranchById(@PathVariable String id){
        return branchService.getById(id);
    }

    @GetMapping
    public List<Branch> getAllBranch(){
        return branchService.getAll();
    }

    @PutMapping
    public Branch updateBranch(@RequestBody Branch branch){
        return branchService.update(branch);
    }
    @DeleteMapping(value = "/{id}")
    public void deleteBranch(@PathVariable String id){
        branchService.deleteById(id);
    }


}
