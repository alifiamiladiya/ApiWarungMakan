package com.enigma.wms_api.Model.Response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class BillDetailResponse {
    private String billDetailId;
    private ProductResponse product;
    private Number quantity;
}