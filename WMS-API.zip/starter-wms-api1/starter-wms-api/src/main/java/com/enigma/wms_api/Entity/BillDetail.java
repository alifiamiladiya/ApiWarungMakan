package com.enigma.wms_api.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "t_bill_detail")
public class BillDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String billDetailId;
    private String billId;
    private Number quantity;
    private BigDecimal totalSales;
}
