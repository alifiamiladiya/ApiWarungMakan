package com.enigma.wms_api.Model.Request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class ProductRequest {
    private String productId;
    @NotBlank(message = "product name is required")
    private String productName;
    @NotBlank(message = "product code is required")
    private String productCode;
    @NotNull(message = "price is required")
    @Min(value = 0 ,message = "price must be greater than equal 0")
    private BigDecimal price;
    @NotNull(message = "stock is required")
    @Min(value = 0 ,message = "stock must be greater than equal 0")
    private Integer stock;
    @NotBlank(message = "branchId is required")
    private String branchId;
}
