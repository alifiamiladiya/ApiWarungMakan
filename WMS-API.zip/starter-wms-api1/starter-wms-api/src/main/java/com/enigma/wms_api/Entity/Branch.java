package com.enigma.wms_api.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "m-branch")
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Branch {
    @Id
    @GenericGenerator(strategy = "uuid2",name = "system-uuid")
    @GeneratedValue(generator = "system-uuid")
    private String branchId;
    @Column(name = "branchCode" , nullable = false , unique = true)
    private String branchCode;
    @Column(name = "branchName" , nullable = false)
    private String branchName;
    @Column(name = "address" , nullable = false)
    private String address;
    @Column(name = "phoneNumber" , nullable = false , unique = true)
    private String phoneNumber;


}
