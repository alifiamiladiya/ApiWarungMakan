package com.enigma.wms_api.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@Entity
@Table(name = "m-transaction")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Transaction {
    @Id
    @GenericGenerator(strategy = "uuid2",name = "system-uuid")
    @GeneratedValue(generator = "system-uuid")
    private String billId;
    @Column(name = "receiptNumber" , nullable = false , unique = true)
    private String receiptNumber;
    @Column(name = "transDate" , nullable = false)
    private String transDate;
    @Column(name = "transactionType" , nullable = false)
    private String transactionType;

}
