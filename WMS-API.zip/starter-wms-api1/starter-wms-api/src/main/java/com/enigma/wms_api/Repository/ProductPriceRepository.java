package com.enigma.wms_api.Repository;

import com.enigma.wms_api.Entity.ProductPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductPriceRepository extends JpaRepository<ProductPrice, String> {
    // Kondisi dimana kita harus pilih dulu price yang aktif atau tidak
    Optional<ProductPrice> findByProduct_IdAndIsActive(String ProductId,Boolean active);

}
