package com.enigma.wms_api.Model.Response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class CommonResponse<T>{
    private Integer statusCode;
    private String error;
    private T data;
    private PagingResponse paging;

}
