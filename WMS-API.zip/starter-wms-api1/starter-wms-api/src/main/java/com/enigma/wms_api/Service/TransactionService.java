package com.enigma.wms_api.Service;

import com.enigma.wms_api.Entity.ProductPrice;
import com.enigma.wms_api.Model.Request.TransactionRequest;
import com.enigma.wms_api.Model.Response.TransactionResponse;

import java.util.List;

public interface TransactionService {
    TransactionResponse createNewTransaction(TransactionRequest orderRequest);
    TransactionResponse getOrderById(String id);
    List<TransactionResponse> getAllTransaction();
}
