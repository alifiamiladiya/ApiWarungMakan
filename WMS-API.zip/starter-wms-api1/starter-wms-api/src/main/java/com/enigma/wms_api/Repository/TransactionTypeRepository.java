package com.enigma.wms_api.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionTypeRepository<TransactionType> extends JpaRepository<TransactionType, String>, JpaSpecificationExecutor<TransactionType> {
}