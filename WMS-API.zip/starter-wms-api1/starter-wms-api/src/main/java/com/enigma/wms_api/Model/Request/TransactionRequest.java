package com.enigma.wms_api.Model.Request;

import com.enigma.wms_api.Model.Response.BillDetailResponse;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class TransactionRequest {
    private String transactionType;
    private List<BillDetailResponse> billDetail;
}
