package com.enigma.wms_api.Service.Impl;

import com.enigma.wms_api.Entity.BillDetail;
import com.enigma.wms_api.Entity.ProductPrice;
import com.enigma.wms_api.Entity.Transaction;
import com.enigma.wms_api.Entity.TransactionType;
import com.enigma.wms_api.Model.Request.TransactionRequest;
import com.enigma.wms_api.Model.Response.BillDetailResponse;
import com.enigma.wms_api.Model.Response.TransactionResponse;
import com.enigma.wms_api.Repository.TransactionRepository;
import com.enigma.wms_api.Service.ProductPriceService;
import com.enigma.wms_api.Service.TransactionService;
import com.enigma.wms_api.Service.TransactionTypeService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final ProductPriceService productPriceService;
    private final TransactionTypeService transactionTypeService

    @Override
    public TransactionResponse createNewTransaction(TransactionRequest orderRequest) {
        return null;
    }

    @Override
    public TransactionResponse getOrderById(String id) {
        return null;
    }

    @Override
    public List<TransactionResponse> getAllTransaction() {
        return null;
    }
}
