package com.enigma.wms_api.Service.Impl;

import com.enigma.wms_api.Entity.Branch;
import com.enigma.wms_api.Model.Response.BranchResponse;
import com.enigma.wms_api.Repository.BranchRepository;
import com.enigma.wms_api.Service.BranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
@RequiredArgsConstructor
public class BranchServiceImpl implements BranchService {
    private final BranchRepository branchRepository;

    @Override
    public Branch create(Branch branch) {
        return branchRepository.save(branch);
    }

    @Override
    public Branch getById(String id) {
        return branchRepository.findById(id).get();
    }

    @Override
    public List<Branch> getAll() {
        return branchRepository.findAll();
    }

    @Override
    public Branch update(Branch branch) {
        Branch currentBranch = getById(branch.getBranchId());
        if (currentBranch != null){
            return branchRepository.save(branch);
        }
        return null;
    }

    @Override
    public void deleteById(String id) {
        branchRepository.deleteById(id
        );
    }

    @Override
    public List<BranchResponse> getAllResponses() {
        return null;
    }


}
