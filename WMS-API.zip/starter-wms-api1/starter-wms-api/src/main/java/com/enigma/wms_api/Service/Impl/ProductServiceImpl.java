package com.enigma.wms_api.Service.Impl;

import com.enigma.wms_api.Entity.Branch;
import com.enigma.wms_api.Entity.Product;
import com.enigma.wms_api.Entity.ProductPrice;
import com.enigma.wms_api.Model.Request.ProductRequest;
import com.enigma.wms_api.Model.Response.BranchResponse;
import com.enigma.wms_api.Model.Response.ProductResponse;
import com.enigma.wms_api.Repository.ProductRepository;
import com.enigma.wms_api.Service.BranchService;
import com.enigma.wms_api.Service.ProductPriceService;
import com.enigma.wms_api.Service.ProductService;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ServiceLoader;

import static com.sun.tools.javac.util.List.filter;

@Service
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private ProductPriceService productPriceService;
    private BranchService branchService;

    @Override
    public Product create(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product getById(String id) {
        return productRepository.findById(id).get();
    }

    @Override
    public List<Product> getAll() {
        return productRepository.findAll();
    }

    @Override
    public Product update(Product product) {
        Product currentProduct = getById(product.getProductId());
        if (currentProduct != null) {
            return productRepository.save(product);
        }
        return null;
    }

    @Override
    public void deleteById(String id) {
        productRepository.deleteById(id);
    }
    @Transactional(rollbackOn = Exception.class)
    @Override
    public ProductResponse createProduct(ProductRequest request) {
        Branch branch = branchService.getById(request.getBranchId());

        Product product = Product.builder()
                .ProductName(request.getProductName())
                .code(request.getProductCode())
                .build();
        productRepository.saveAndFlush(product);

        ProductPrice productPrice = ProductPrice.builder()
                .price(request.getPrice())
                .stock(request.getStock())
                .branch(branch)
                .product(product)
                .isActive(true)
                .build();
        productPriceService.create(productPrice);
        return new ProductResponse(branch, product, productPrice);
    }

    private static ProductResponse toProductResponse(Branch branch, Product product, ProductPrice productPrice) {
        return ProductResponse.builder()
                .productId(product.getProductId())
                .productPriceId(product.getProductPriceId())
                .productName(product.getProductName())
                .productCode(product.getProductCode())
                .price(productPrice.getPrice())
                .stock(productPrice.getStock())
                .branch(BranchResponse.builder()
                        .branchId(branch.getBranchId())
                        .branchName(branch.getBranchName())
                        .branchCode(branch.getBranchCode())
                        .address(branch.getAddress())
                        .phoneNumber(branch.getPhoneNumber())
                        .build())
                .build();
    }
    @Override
    public Page<ProductResponse> getAllByNameOrPrice(String name, Long maxPrice, Integer page, Integer size) {
        Specification<Product> specification = (root, query , criteriaBuilder ) ->{
            Join<Product , ProductPrice> productPrices = root.join("productPrices");
            List<Predicate> predicates = new ArrayList<>();
            if (name != null){
                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("name")),"%" + name.toLowerCase() + "%"));
            }
            if (maxPrice != null){
                predicates.add(criteriaBuilder.lessThanOrEqualTo(productPrices.get("price"), maxPrice));
            }
            return  query.where(predicates.toArray(new Predicate[]{})).getRestriction();
        };
        Pageable pageable = PageRequest.of(page,size);
        Page<Product> products = productRepository.findAll(specification,pageable);
        List<ProductResponse> productResponses = new ArrayList<>();
        for (Product product : products.getContent()){
            Optional<ProductPrice> productPrice = product.getProductPrices
                    .stream();
                    .filter(ProductPrice::getIsActive).findFirst();
            if (productPrice.isEmpty()) continue;
            Branch branch = productPrice.get().getBranch();

            productResponses.add(toProductResponse(branch,product,productPrice.get()));
        }
        return new PageImpl<>(productResponses,pageable,products.getTotalElements());
    }

    private ServiceLoader<Object> filter(Object getIsActive) {
        return null;
    }

}
