package com.enigma.wms_api.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "m_product_price")
@Builder(toBuilder = true)
public class ProductPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(columnDefinition = "int check (stock > 0)")
    private Integer stock;
    @Column
    private Boolean isActive;
    @Column(columnDefinition = "bigint check (price > 0)")
    private BigDecimal price;

    @ManyToOne
    @JoinColumn(name = "productId")
    @JsonBackReference
    private Product product;

    @ManyToOne
    @JoinColumn(name = "branchId")
    private Branch branch;
}

