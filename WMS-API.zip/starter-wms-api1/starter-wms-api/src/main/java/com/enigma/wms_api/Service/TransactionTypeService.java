package com.enigma.wms_api.Service;

import com.enigma.wms_api.Entity.TransactionType;


import java.util.List;

public interface TransactionTypeService {

    TransactionType create(TransactionType transactionType);
    TransactionType getById(String id);
    List<TransactionType> getAll();
    TransactionType update(TransactionType transactionType);
    void deleteById(String id);

}