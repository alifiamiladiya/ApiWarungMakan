package com.enigma.wms_api.Controller;

import com.enigma.wms_api.Model.Request.TransactionRequest;
import com.enigma.wms_api.Model.Response.CommonResponse;
import com.enigma.wms_api.Model.Response.TransactionResponse;
import com.enigma.wms_api.Service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping
    public ResponseEntity<?> createNewTransaction(@RequestBody TransactionRequest request) {
        TransactionResponse transactionResponse = transactionService.createNewTransaction(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(CommonResponse.builder()
                        .statusCode(HttpStatus.CREATED.value())
                        .error("Not Success create new transaction")
                        .data(transactionResponse)
                        .build());
    }

}
