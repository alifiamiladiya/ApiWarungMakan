package com.enigma.wms_api.Model.Request;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class BillDetailRequest {
    private String productPriceId;
    private Integer quantity;
}
