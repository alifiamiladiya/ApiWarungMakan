package com.enigma.wms_api.Service;

import com.enigma.wms_api.Entity.Product;
import com.enigma.wms_api.Model.Request.ProductRequest;
import com.enigma.wms_api.Model.Response.ProductResponse;
import org.springframework.data.domain.Page;

import java.util.List;

public interface ProductService {
    Product create(Product product);
    Product getById(String id);
    List<Product> getAll();
    Product update(Product product);
    void deleteById(String id);
    ProductResponse createProduct(ProductRequest request);

    Page<ProductResponse> getAllByNameOrPrice(String name , Long maxPrice , Integer page , Integer size);

}
