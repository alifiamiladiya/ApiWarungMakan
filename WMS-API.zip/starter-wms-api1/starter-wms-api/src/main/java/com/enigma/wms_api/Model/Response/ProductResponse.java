package com.enigma.wms_api.Model.Response;

import com.enigma.wms_api.Entity.Branch;
import com.enigma.wms_api.Entity.Product;
import com.enigma.wms_api.Entity.ProductPrice;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class ProductResponse {
        private String productId;
        private String productPriceId;
        private String productCode;
        private String productName;
        private Integer stock;
        private BigDecimal price;
        private BranchResponse branch;

        public ProductResponse(Branch branch, Product product, ProductPrice productPrice) {
        }
}
